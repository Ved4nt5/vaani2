# Vaani — Android App (Kotlin & Jetpack Compose)

Modern, minimal Android application for **Vaani: AI Voice to Text & Summarizer**. Connects directly to the Vaani backend and SQLite database via dynamic Cloudflare tunnels.

## Key Features

1. **Modern Minimal Android Material 3 UI**:
   - Custom Material 3 theme (`VaaniTheme`) with clean typography, rounded surfaces, and high contrast accents.
   - Standard Android Bottom Navigation Bar with 5 core tabs:
     - 🏠 **Home / Dashboard**: Overview, quick stats, recent lectures, jump to audio.
     - 📁 **Library / Boxes**: Storage boxes categorized by subject and course.
     - 📚 **Lectures**: Searchable lectures with subject filters and one-tap audio streaming.
     - 🎙️ **Record**: Voice recording with live timer, waveform preview, and instant AI transcription & summarization.
     - ☁️ **Tunnel**: Dedicated Cloudflare Tunnel configuration with live ping test, latency counter, and connection status.
2. **Dynamic Cloudflare Tunnel Connection**:
   - Built for hosting via `cloudflared tunnel --url http://localhost:3000`.
   - In-app setting allows updating the tunnel URL anytime without rebuilding or reinstalling the app.
   - Built-in ping test validates `/api/health`, measures roundtrip latency, and confirms database status.
   - Custom `network_security_config.xml` enables seamless connections to both HTTPS Cloudflare tunnels and local HTTP emulator/LAN endpoints (`10.0.2.2:3000`).
3. **Audio Streaming & AI Notes**:
   - Integrated Media3 ExoPlayer for real-time lecture audio streaming.
   - Floating audio player bottom bar with progress tracking and playback controls.
   - Verbatim speech-to-text transcript and structured academic exam revision notes (Overview, Key Concepts, Definitions, Takeaways).

## How to Run in Android Studio

1. Open Android Studio (Ladybug / Koala / Hedgehog or newer).
2. Click **Open** and select the `android/` directory.
3. Allow Gradle to sync dependencies.
4. Run the app on an Android Emulator or physical device (MinSdk: Android 8.0 Oreo, TargetSdk: Android 15 / API 35).

## How to Connect to Cloudflare Tunnel

1. On your backend machine, run:
   ```bash
   cloudflared tunnel --url http://localhost:3000
   ```
2. Copy the tunnel URL output (e.g. `https://random-name.trycloudflare.com`).
3. Open the Vaani Android app, navigate to the **Tunnel** tab at the bottom bar.
4. Paste your tunnel URL and tap **Test Ping**, then tap **Save Tunnel**.
5. All app requests will route through your Cloudflare tunnel!
