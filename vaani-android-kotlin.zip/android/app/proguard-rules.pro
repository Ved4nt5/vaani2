# Proguard rules for Vaani Android App
-keep class com.vaani.app.data.model.** { *; }
-dontwarn okhttp3.**
-dontwarn retrofit2.**
