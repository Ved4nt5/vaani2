package com.vaani.app.data.api

import com.vaani.app.data.model.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface VaaniApiService {

    @GET("api/health")
    suspend fun checkHealth(): Response<HealthResponse>

    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    @GET("api/auth/me")
    suspend fun getMe(): Response<UserDto>

    @POST("api/auth/logout")
    suspend fun logout(): Response<Unit>

    @GET("api/recordings")
    suspend fun getRecordings(
        @Query("role") role: String? = null
    ): Response<List<RecordingDto>>

    @GET("api/recordings/{id}")
    suspend fun getRecording(
        @Path("id") id: Int
    ): Response<RecordingDto>

    @GET("api/boxes")
    suspend fun getStorageBoxes(): Response<List<StorageBoxDto>>

    @GET("api/boxes/{id}")
    suspend fun getStorageBoxDetails(
        @Path("id") id: Int
    ): Response<StorageBoxDetailDto>

    @Multipart
    @POST("api/recordings")
    suspend fun uploadRecording(
        @Part file: MultipartBody.Part,
        @Part("title") title: RequestBody,
        @Part("subject") subject: RequestBody?,
        @Part("classCourse") classCourse: RequestBody?,
        @Part("description") description: RequestBody?,
        @Part("duration") duration: RequestBody?,
        @Part("storageBoxId") storageBoxId: RequestBody?,
        @Part("mode") mode: RequestBody?
    ): Response<RecordingDto>

    @POST("api/recordings/{id}/publish")
    suspend fun publishLecture(
        @Path("id") id: Int,
        @Body body: Map<String, Boolean>
    ): Response<RecordingDto>
}
