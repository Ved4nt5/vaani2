package com.vaani.app

import android.app.Application
import com.vaani.app.data.api.DynamicRetrofitClient
import com.vaani.app.data.preferences.TunnelPreferences

class VaaniApplication : Application() {

    lateinit var preferences: TunnelPreferences
        private set

    lateinit var retrofitClient: DynamicRetrofitClient
        private set

    override fun onCreate() {
        super.onCreate()
        preferences = TunnelPreferences(this)
        retrofitClient = DynamicRetrofitClient(preferences)
    }
}
