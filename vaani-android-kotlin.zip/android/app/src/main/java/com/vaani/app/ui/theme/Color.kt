package com.vaani.app.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryIndigo = Color(0xFF5B2BE0)
val PrimaryIndigoVariant = Color(0xFF481EC0)
val PrimaryLight = Color(0xFF7E56F5)

val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF3F0FA)
val BackgroundLight = Color(0xFFF8F7FC)

val TextPrimary = Color(0xFF18162B)
val TextSecondary = Color(0xFF6B677F)
val TextTertiary = Color(0xFF9E9AA8)

val BorderLight = Color(0xFFE5E2EE)
val AccentGreen = Color(0xFF10B981)
val AccentAmber = Color(0xFFF59E0B)
val AccentRose = Color(0xFFEF4444)

// Dark Theme Colors
val PrimaryDark = Color(0xFFB39DDB)
val SurfaceDark = Color(0xFF1E1B2E)
val SurfaceVariantDark = Color(0xFF28243D)
val BackgroundDark = Color(0xFF12101C)
val TextPrimaryDark = Color(0xFFF3F0FA)
val TextSecondaryDark = Color(0xFFA5A0B8)
val BorderDark = Color(0xFF2E2A44)
