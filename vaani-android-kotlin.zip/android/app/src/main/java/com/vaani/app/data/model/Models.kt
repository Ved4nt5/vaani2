package com.vaani.app.data.model

import com.google.gson.annotations.SerializedName

data class HealthResponse(
    @SerializedName("status") val status: String,
    @SerializedName("app") val app: String,
    @SerializedName("version") val version: String,
    @SerializedName("database") val database: String,
    @SerializedName("databaseType") val databaseType: String?,
    @SerializedName("tunnelReady") val tunnelReady: Boolean?,
    @SerializedName("timestamp") val timestamp: String?,
    @SerializedName("metrics") val metrics: SystemMetrics?
)

data class SystemMetrics(
    @SerializedName("recordingsCount") val recordingsCount: Int,
    @SerializedName("storageBoxesCount") val storageBoxesCount: Int,
    @SerializedName("usersCount") val usersCount: Int
)

data class LoginRequest(
    @SerializedName("email") val email: String,
    @SerializedName("password") val password: String,
    @SerializedName("role") val role: String = "student"
)

data class LoginResponse(
    @SerializedName("token") val token: String,
    @SerializedName("name") val name: String,
    @SerializedName("email") val email: String,
    @SerializedName("role") val role: String,
    @SerializedName("facultyId") val facultyId: String?,
    @SerializedName("department") val department: String?,
    @SerializedName("avatarUrl") val avatarUrl: String?,
    @SerializedName("error") val error: String?
)

data class UserDto(
    @SerializedName("name") val name: String,
    @SerializedName("email") val email: String,
    @SerializedName("role") val role: String,
    @SerializedName("facultyId") val facultyId: String? = null,
    @SerializedName("department") val department: String? = null,
    @SerializedName("avatarUrl") val avatarUrl: String? = null
)

data class RecordingDto(
    @SerializedName("id") val id: Int,
    @SerializedName("storageBoxId") val storageBoxId: Int?,
    @SerializedName("storageBoxName") val storageBoxName: String?,
    @SerializedName("title") val title: String,
    @SerializedName("lectureName") val lectureName: String?,
    @SerializedName("professorName") val professorName: String?,
    @SerializedName("subject") val subject: String?,
    @SerializedName("classCourse") val classCourse: String?,
    @SerializedName("lectureDate") val lectureDate: String?,
    @SerializedName("description") val description: String?,
    @SerializedName("duration") val duration: String,
    @SerializedName("createdAt") val createdAt: String,
    @SerializedName("status") val status: String,
    @SerializedName("facultyStatus") val facultyStatus: String?,
    @SerializedName("published") val published: Boolean,
    @SerializedName("studentsAccessed") val studentsAccessed: Int,
    @SerializedName("playsCount") val playsCount: Int,
    @SerializedName("avgListeningTime") val avgListeningTime: String,
    @SerializedName("transcript") val transcript: String,
    @SerializedName("summary") val summary: String,
    @SerializedName("hasAudio") val hasAudio: Boolean,
    @SerializedName("audioUrl") val audioUrl: String?
)

data class StorageBoxDto(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String,
    @SerializedName("description") val description: String,
    @SerializedName("createdBy") val createdBy: String,
    @SerializedName("facultyId") val facultyId: String?,
    @SerializedName("allowedStudents") val allowedStudents: List<String>?,
    @SerializedName("recordingCount") val recordingCount: Int,
    @SerializedName("publishedRecordingCount") val publishedRecordingCount: Int,
    @SerializedName("createdAt") val createdAt: String,
    @SerializedName("updatedAt") val updatedAt: String,
    @SerializedName("lastUpdatedFormatted") val lastUpdatedFormatted: String
)

data class StorageBoxDetailDto(
    @SerializedName("box") val box: StorageBoxDto,
    @SerializedName("recordings") val recordings: List<RecordingDto>
)
