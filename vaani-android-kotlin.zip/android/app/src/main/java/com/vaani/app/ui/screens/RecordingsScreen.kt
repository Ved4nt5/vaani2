package com.vaani.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vaani.app.data.api.DynamicRetrofitClient
import com.vaani.app.data.model.RecordingDto
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordingsScreen(
    client: DynamicRetrofitClient,
    onSelectLecture: (Int) -> Unit,
    onPlayLecture: (RecordingDto) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var recordings by remember { mutableStateOf<List<RecordingDto>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedSubject by remember { mutableStateOf("All") }
    var isLoading by remember { mutableStateOf(true) }

    fun loadData() {
        coroutineScope.launch {
            isLoading = true
            try {
                val res = client.apiService.getRecordings()
                if (res.isSuccessful) {
                    recordings = res.body() ?: emptyList()
                }
            } catch (e: Exception) {
                // handle error
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    // Compute distinct subjects for filters
    val subjects = remember(recordings) {
        listOf("All") + recordings.mapNotNull { it.subject }.distinct()
    }

    val filtered = remember(recordings, searchQuery, selectedSubject) {
        recordings.filter { rec ->
            val matchesSearch = searchQuery.isBlank() ||
                rec.title.contains(searchQuery, ignoreCase = true) ||
                (rec.subject ?: "").contains(searchQuery, ignoreCase = true) ||
                (rec.professorName ?: "").contains(searchQuery, ignoreCase = true)

            val matchesSubject = selectedSubject == "All" || rec.subject == selectedSubject
            matchesSearch && matchesSubject
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Lectures & Audio Notes",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search by topic, professor, or subject...") },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        // Subject Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            subjects.forEach { subj ->
                FilterChip(
                    selected = selectedSubject == subj,
                    onClick = { selectedSubject = subj },
                    label = { Text(subj) },
                    shape = RoundedCornerShape(8.dp)
                )
            }
        }

        // Lectures List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filtered) { rec ->
                LectureCard(
                    recording = rec,
                    onClick = { onSelectLecture(rec.id) },
                    onPlay = { onPlayLecture(rec) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}
