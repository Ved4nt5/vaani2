package com.vaani.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaani.app.data.api.DynamicRetrofitClient
import com.vaani.app.data.model.LoginRequest
import com.vaani.app.data.model.UserDto
import com.vaani.app.data.preferences.TunnelPreferences
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    client: DynamicRetrofitClient,
    preferences: TunnelPreferences,
    onLoginSuccess: () -> Unit,
    onOpenTunnelSettings: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var email by remember { mutableStateOf("programmmariojs8@gmail.com") }
    var password by remember { mutableStateOf("password123") }
    var selectedRole by remember { mutableStateOf("student") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val activeTunnel = remember { preferences.getTunnelUrl() }

    fun doLogin() {
        coroutineScope.launch {
            isLoading = true
            errorMessage = null
            try {
                val res = client.apiService.login(
                    LoginRequest(
                        email = email.trim(),
                        password = password.trim(),
                        role = selectedRole
                    )
                )

                if (res.isSuccessful && res.body()?.token != null) {
                    val body = res.body()!!
                    preferences.setAuthToken(body.token)
                    preferences.setUser(
                        UserDto(
                            name = body.name,
                            email = body.email,
                            role = body.role,
                            facultyId = body.facultyId,
                            department = body.department,
                            avatarUrl = body.avatarUrl
                        )
                    )
                    onLoginSuccess()
                } else {
                    errorMessage = res.body()?.error ?: "Invalid credentials or unauthorized role."
                }
            } catch (e: Exception) {
                errorMessage = "Tunnel connection error: ${e.localizedMessage ?: "Check tunnel URL in settings"}"
            } finally {
                isLoading = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Vaani AI",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary
        )

        Text(
            text = "AI Voice to Text & Lecture Summarizer",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.65f)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Role Segmented Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    selectedRole = "student"
                    if (email.contains("faculty")) email = "programmmariojs8@gmail.com"
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedRole == "student") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = if (selectedRole == "student") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Student")
            }

            Button(
                onClick = {
                    selectedRole = "faculty"
                    if (email.contains("mario") || email.contains("student")) email = "faculty@vaani.edu"
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedRole == "faculty") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = if (selectedRole == "faculty") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Faculty")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Card form
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    leadingIcon = { Icon(Icons.Outlined.Email, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    leadingIcon = { Icon(Icons.Outlined.Lock, contentDescription = null) },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Button(
                    onClick = { doLogin() },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isLoading
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text("Sign In as ${selectedRole.replaceFirstChar { it.uppercase() }}")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tunnel Info Link
        TextButton(onClick = onOpenTunnelSettings) {
            Icon(Icons.Outlined.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Active Tunnel: ${activeTunnel.take(30)}... (Tap to edit)", fontSize = 12.sp)
        }
    }
}
