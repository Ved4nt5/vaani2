package com.vaani.app.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Dashboard : Screen("dashboard", "Home")
    object StorageBoxes : Screen("boxes", "Library")
    object Recordings : Screen("recordings", "Lectures")
    object Record : Screen("record", "Record")
    object Settings : Screen("settings", "Tunnel")
    object LectureDetail : Screen("lecture/{id}", "Lecture Details") {
        fun createRoute(id: Int) = "lecture/$id"
    }
    object Login : Screen("login", "Sign In")
}

val BottomNavItems = listOf(
    Screen.Dashboard,
    Screen.StorageBoxes,
    Screen.Recordings,
    Screen.Record,
    Screen.Settings
)
