package com.vaani.app.data.preferences

import android.content.Context
import android.content.SharedPreferences
import com.vaani.app.data.model.UserDto

class TunnelPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("vaani_tunnel_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_TUNNEL_URL = "key_tunnel_url"
        private const val KEY_AUTH_TOKEN = "key_auth_token"
        private const val KEY_USER_NAME = "key_user_name"
        private const val KEY_USER_EMAIL = "key_user_email"
        private const val KEY_USER_ROLE = "key_user_role"

        // Default URL: local Android emulator host (10.0.2.2:3000) or prompt URL
        const val DEFAULT_TUNNEL_URL = "http://10.0.2.2:3000"
    }

    /**
     * Get the active Cloudflare Tunnel URL or base backend URL.
     * Guaranteed to return a valid URL without trailing slash.
     */
    fun getTunnelUrl(): String {
        val saved = prefs.getString(KEY_TUNNEL_URL, null)
        if (!saved.isNullOrBlank()) {
            return normalizeUrl(saved)
        }
        return DEFAULT_TUNNEL_URL
    }

    /**
     * Save a new Cloudflare Tunnel URL (e.g., https://my-random-name.trycloudflare.com).
     */
    fun setTunnelUrl(url: String) {
        val clean = normalizeUrl(url)
        prefs.edit().putString(KEY_TUNNEL_URL, clean).apply()
    }

    /**
     * Reset tunnel to default emulator URL.
     */
    fun resetTunnelUrl() {
        prefs.edit().remove(KEY_TUNNEL_URL).apply()
    }

    fun getAuthToken(): String? {
        return prefs.getString(KEY_AUTH_TOKEN, null)
    }

    fun setAuthToken(token: String?) {
        if (token.isNullOrBlank()) {
            prefs.edit().remove(KEY_AUTH_TOKEN).apply()
        } else {
            prefs.edit().putString(KEY_AUTH_TOKEN, token).apply()
        }
    }

    fun getUser(): UserDto? {
        val email = prefs.getString(KEY_USER_EMAIL, null) ?: return null
        val name = prefs.getString(KEY_USER_NAME, "User") ?: "User"
        val role = prefs.getString(KEY_USER_ROLE, "student") ?: "student"
        return UserDto(name = name, email = email, role = role)
    }

    fun setUser(user: UserDto?) {
        if (user == null) {
            prefs.edit()
                .remove(KEY_USER_NAME)
                .remove(KEY_USER_EMAIL)
                .remove(KEY_USER_ROLE)
                .apply()
        } else {
            prefs.edit()
                .putString(KEY_USER_NAME, user.name)
                .putString(KEY_USER_EMAIL, user.email)
                .putString(KEY_USER_ROLE, user.role)
                .apply()
        }
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_AUTH_TOKEN)
            .remove(KEY_USER_NAME)
            .remove(KEY_USER_EMAIL)
            .remove(KEY_USER_ROLE)
            .apply()
    }

    private fun normalizeUrl(url: String): String {
        var trimmed = url.trim()
        if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
            trimmed = "https://$trimmed"
        }
        if (trimmed.endsWith("/")) {
            trimmed = trimmed.substring(0, trimmed.length - 1)
        }
        return trimmed
    }
}
