package com.vaani.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.vaani.app.data.model.RecordingDto
import com.vaani.app.ui.components.AudioPlayerBottomBar
import com.vaani.app.ui.components.VaaniBottomNavBar
import com.vaani.app.ui.navigation.Screen
import com.vaani.app.ui.screens.*
import com.vaani.app.ui.theme.VaaniTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private var exoPlayer: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as VaaniApplication
        val preferences = app.preferences
        val client = app.retrofitClient

        exoPlayer = ExoPlayer.Builder(this).build()

        setContent {
            VaaniTheme {
                var currentScreen by remember { mutableStateOf<Screen>(Screen.Dashboard) }
                var selectedLectureId by remember { mutableStateOf<Int?>(null) }
                var activePlayingLecture by remember { mutableStateOf<RecordingDto?>(null) }
                var isPlaying by remember { mutableStateOf(false) }
                var playbackProgress by remember { mutableStateOf(0f) }

                // Periodic playback progress poll
                LaunchedEffect(isPlaying) {
                    while (isPlaying && exoPlayer != null) {
                        val duration = exoPlayer!!.duration
                        val position = exoPlayer!!.currentPosition
                        if (duration > 0) {
                            playbackProgress = position.toFloat() / duration.toFloat()
                        }
                        delay(500)
                    }
                }

                fun playLecture(rec: RecordingDto) {
                    activePlayingLecture = rec
                    val streamUrl = client.resolveAudioStreamUrl("/api/recordings/${rec.id}/audio")
                    try {
                        exoPlayer?.let { player ->
                            player.stop()
                            player.clearMediaItems()
                            player.setMediaItem(MediaItem.fromUri(Uri.parse(streamUrl)))
                            player.prepare()
                            player.play()
                            isPlaying = true
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                fun togglePlay() {
                    exoPlayer?.let { player ->
                        if (player.isPlaying) {
                            player.pause()
                            isPlaying = false
                        } else {
                            player.play()
                            isPlaying = true
                        }
                    }
                }

                // Check auth
                var isLoggedIn by remember { mutableStateOf(preferences.getAuthToken() != null) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (isLoggedIn) {
                            Column {
                                // Floating audio player above bottom bar
                                AudioPlayerBottomBar(
                                    recording = activePlayingLecture,
                                    isPlaying = isPlaying,
                                    progress = playbackProgress,
                                    onTogglePlay = { togglePlay() },
                                    onExpand = {
                                        activePlayingLecture?.let {
                                            selectedLectureId = it.id
                                        }
                                    }
                                )

                                // Modern minimal Android bottom navigation bar
                                VaaniBottomNavBar(
                                    currentRoute = currentScreen.route,
                                    onNavigate = { screen ->
                                        selectedLectureId = null
                                        currentScreen = screen
                                    }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (!isLoggedIn) {
                            LoginScreen(
                                client = client,
                                preferences = preferences,
                                onLoginSuccess = { isLoggedIn = true },
                                onOpenTunnelSettings = {
                                    isLoggedIn = true
                                    currentScreen = Screen.Settings
                                }
                            )
                        } else if (selectedLectureId != null) {
                            LectureDetailScreen(
                                recordingId = selectedLectureId!!,
                                client = client,
                                onBack = { selectedLectureId = null },
                                onPlay = { playLecture(it) }
                            )
                        } else {
                            when (currentScreen) {
                                Screen.Dashboard -> DashboardScreen(
                                    client = client,
                                    preferences = preferences,
                                    onSelectLecture = { selectedLectureId = it },
                                    onPlayLecture = { playLecture(it) },
                                    onNavigateToRecord = { currentScreen = Screen.Record },
                                    onNavigateToSettings = { currentScreen = Screen.Settings }
                                )
                                Screen.StorageBoxes -> StorageBoxesScreen(
                                    client = client,
                                    onSelectBox = {
                                        currentScreen = Screen.Recordings
                                    }
                                )
                                Screen.Recordings -> RecordingsScreen(
                                    client = client,
                                    onSelectLecture = { selectedLectureId = it },
                                    onPlayLecture = { playLecture(it) }
                                )
                                Screen.Record -> RecordScreen(
                                    client = client,
                                    onLectureCreated = { id ->
                                        selectedLectureId = id
                                    }
                                )
                                Screen.Settings -> SettingsTunnelScreen(
                                    preferences = preferences,
                                    client = client,
                                    onLogout = {
                                        preferences.clearSession()
                                        isLoggedIn = false
                                        exoPlayer?.stop()
                                        isPlaying = false
                                        activePlayingLecture = null
                                    }
                                )
                                else -> DashboardScreen(
                                    client = client,
                                    preferences = preferences,
                                    onSelectLecture = { selectedLectureId = it },
                                    onPlayLecture = { playLecture(it) },
                                    onNavigateToRecord = { currentScreen = Screen.Record },
                                    onNavigateToSettings = { currentScreen = Screen.Settings }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        exoPlayer?.release()
        exoPlayer = null
    }
}
