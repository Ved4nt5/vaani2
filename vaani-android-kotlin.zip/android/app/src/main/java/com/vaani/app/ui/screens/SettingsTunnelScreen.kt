package com.vaani.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaani.app.data.api.DynamicRetrofitClient
import com.vaani.app.data.model.HealthResponse
import com.vaani.app.data.preferences.TunnelPreferences
import kotlinx.coroutines.launch
import kotlin.system.measureTimeMillis

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsTunnelScreen(
    preferences: TunnelPreferences,
    client: DynamicRetrofitClient,
    onLogout: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    var tunnelInput by remember { mutableStateOf(preferences.getTunnelUrl()) }
    var isTesting by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var isConnected by remember { mutableStateOf(false) }
    var pingMs by remember { mutableStateOf<Long?>(null) }
    var healthInfo by remember { mutableStateOf<HealthResponse?>(null) }
    var saveMessage by remember { mutableStateOf<String?>(null) }

    val currentUser = remember { preferences.getUser() }

    // Test connection function
    fun testConnection() {
        coroutineScope.launch {
            isTesting = true
            testResult = null
            saveMessage = null
            try {
                // Temporarily apply input to preferences so dynamicInterceptor tests it
                val previousUrl = preferences.getTunnelUrl()
                preferences.setTunnelUrl(tunnelInput)

                var response: retrofit2.Response<HealthResponse>? = null
                val latency = measureTimeMillis {
                    response = client.apiService.checkHealth()
                }

                if (response?.isSuccessful == true && response?.body()?.status == "online") {
                    isConnected = true
                    pingMs = latency
                    healthInfo = response?.body()
                    testResult = "Tunnel Connected! Latency: ${latency}ms · DB: ${healthInfo?.database ?: "OK"}"
                } else {
                    isConnected = false
                    pingMs = null
                    testResult = "Connection failed: HTTP ${response?.code()} ${response?.message()}"
                    preferences.setTunnelUrl(previousUrl) // rollback
                }
            } catch (e: Exception) {
                isConnected = false
                pingMs = null
                testResult = "Error connecting to tunnel: ${e.localizedMessage ?: "Network unreachable"}"
            } finally {
                isTesting = false
            }
        }
    }

    // Auto-ping active tunnel on screen load
    LaunchedEffect(Unit) {
        testConnection()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Column {
            Text(
                text = "Cloudflare Tunnel & Settings",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Connect this app to your active backend tunnel each time it changes.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
        }

        // Live Connection Status Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isConnected) Color(0xFFF0FDF4) else Color(0xFFFEF2F2)
            ),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(
                    if (isConnected) Color(0xFF86EFAC) else Color(0xFFFECACA)
                )
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isConnected) Color(0xFF16A34A) else Color(0xFFDC2626))
                )

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isConnected) "Backend Online & Connected" else "Not Connected to Tunnel",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isConnected) Color(0xFF14532D) else Color(0xFF7F1D1D)
                    )
                    Text(
                        text = testResult ?: "Enter your tunnel URL below and tap Test Connection.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isConnected) Color(0xFF166534) else Color(0xFF991B1B)
                    )
                    if (isConnected && healthInfo?.metrics != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "SQLite Database: ${healthInfo?.metrics?.recordingsCount ?: 0} lectures · ${healthInfo?.metrics?.storageBoxesCount ?: 0} boxes",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFF15803D)
                        )
                    }
                }

                if (isTesting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Cloudflare Tunnel URL Input Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudQueue,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Active Cloudflare Tunnel URL",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                OutlinedTextField(
                    value = tunnelInput,
                    onValueChange = {
                        tunnelInput = it
                        saveMessage = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Tunnel Endpoint") },
                    placeholder = { Text("https://xxx-yyy.trycloudflare.com") },
                    singleLine = true,
                    leadingIcon = {
                        Icon(Icons.Outlined.Link, contentDescription = null)
                    },
                    trailingIcon = {
                        IconButton(onClick = {
                            val clipText = clipboardManager.getText()?.text
                            if (!clipText.isNullOrBlank()) {
                                tunnelInput = clipText
                            }
                        }) {
                            Icon(Icons.Outlined.ContentPaste, contentDescription = "Paste from Clipboard")
                        }
                    },
                    shape = RoundedCornerShape(12.dp)
                )

                // Quick Presets
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = tunnelInput.contains("trycloudflare.com"),
                        onClick = {
                            if (!tunnelInput.contains("trycloudflare.com")) {
                                tunnelInput = "https://your-tunnel.trycloudflare.com"
                            }
                        },
                        label = { Text("Cloudflare Tunnel", fontSize = 12.sp) }
                    )
                    FilterChip(
                        selected = tunnelInput == "http://10.0.2.2:3000",
                        onClick = { tunnelInput = "http://10.0.2.2:3000" },
                        label = { Text("Emulator 10.0.2.2", fontSize = 12.sp) }
                    )
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { testConnection() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        enabled = !isTesting
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Ping")
                    }

                    Button(
                        onClick = {
                            preferences.setTunnelUrl(tunnelInput)
                            saveMessage = "Tunnel saved and active!"
                            testConnection()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Tunnel")
                    }
                }

                if (saveMessage != null) {
                    Text(
                        text = saveMessage!!,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Cloudflare Setup Guide Helper Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Outlined.Terminal, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(
                        text = "How to Host with Cloudflare Tunnel",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Text(
                    text = "1. In your backend terminal, launch a free tunnel to port 3000:",
                    style = MaterialTheme.typography.bodyMedium
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "cloudflared tunnel --url http://localhost:3000",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.5.sp,
                        modifier = Modifier.padding(10.dp),
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Text(
                    text = "2. Copy the resulting `https://...trycloudflare.com` URL.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "3. Paste it in the Tunnel field above and tap 'Save Tunnel'. All app requests will route through it!",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // User Account & Session Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Outlined.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(
                        text = "Account Session",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (currentUser != null) {
                    Text(
                        text = "${currentUser.name} (${currentUser.role.uppercase()})",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = currentUser.email,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                } else {
                    Text(
                        text = "Guest / Not signed in",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }

                OutlinedButton(
                    onClick = onLogout,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.ExitToApp, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (currentUser != null) "Sign Out / Change User" else "Sign In")
                }
            }
        }
    }
}
