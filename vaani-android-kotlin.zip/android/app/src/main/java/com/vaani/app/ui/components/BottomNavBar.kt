package com.vaani.app.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.vaani.app.ui.navigation.BottomNavItems
import com.vaani.app.ui.navigation.Screen

@Composable
fun VaaniBottomNavBar(
    currentRoute: String?,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier,
        tonalElevation = 4.dp,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        BottomNavItems.forEach { screen ->
            val selected = currentRoute == screen.route
            val icon = getIconForScreen(screen, selected)

            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(screen) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = screen.title
                    )
                },
                label = {
                    Text(
                        text = screen.title,
                        style = MaterialTheme.typography.labelMedium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    unselectedTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            )
        }
    }
}

private fun getIconForScreen(screen: Screen, selected: Boolean): ImageVector {
    return when (screen) {
        Screen.Dashboard -> if (selected) Icons.Filled.Home else Icons.Outlined.Home
        Screen.StorageBoxes -> if (selected) Icons.Filled.Folder else Icons.Outlined.Folder
        Screen.Recordings -> if (selected) Icons.Filled.MenuBook else Icons.Outlined.MenuBook
        Screen.Record -> if (selected) Icons.Filled.Mic else Icons.Outlined.Mic
        Screen.Settings -> if (selected) Icons.Filled.CloudSync else Icons.Outlined.CloudSync
        else -> Icons.Outlined.Circle
    }
}
