package com.vaani.app.data.api

import com.vaani.app.data.preferences.TunnelPreferences
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class DynamicRetrofitClient(private val preferences: TunnelPreferences) {

    private val dynamicInterceptor = Interceptor { chain ->
        var originalRequest = chain.request()

        // 1. Rewrite base URL dynamically from current tunnel preferences
        val currentTunnelUrl = preferences.getTunnelUrl()
        val newBaseUrl = currentTunnelUrl.toHttpUrlOrNull()

        if (newBaseUrl != null) {
            val newUrl = originalRequest.url.newBuilder()
                .scheme(newBaseUrl.scheme)
                .host(newBaseUrl.host)
                .port(newBaseUrl.port)
                .build()

            val requestBuilder = originalRequest.newBuilder().url(newUrl)

            // 2. Attach Authorization Bearer token if present
            val token = preferences.getAuthToken()
            if (!token.isNullOrBlank() && originalRequest.header("Authorization") == null) {
                requestBuilder.addHeader("Authorization", "Bearer $token")
            }

            // 3. User-Agent
            requestBuilder.addHeader("User-Agent", "Vaani-Android-App/1.0")

            originalRequest = requestBuilder.build()
        }

        chain.proceed(originalRequest)
    }

    private val okHttpClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        OkHttpClient.Builder()
            .addInterceptor(dynamicInterceptor)
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(45, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    /**
     * Creates or returns the API service instance with dynamic URL dispatching.
     */
    val apiService: VaaniApiService by lazy {
        Retrofit.Builder()
            .baseUrl("http://localhost/") // Base URL placeholder; dynamicInterceptor rewrites host on each call
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(VaaniApiService::class.java)
    }

    /**
     * Resolves a relative audio URL (/api/recordings/1/audio) to full tunnel URL.
     */
    fun resolveAudioStreamUrl(relativePath: String): String {
        val base = preferences.getTunnelUrl().trimEnd('/')
        val path = if (relativePath.startsWith("/")) relativePath else "/$relativePath"
        val token = preferences.getAuthToken()
        return if (!token.isNullOrBlank()) {
            "$base$path?token=$token"
        } else {
            "$base$path"
        }
    }
}
